from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
import sqlite3

# Database init
conn = sqlite3.connect('pos.db')
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS users (email TEXT, password TEXT)")
conn.commit()

# Screens
class LoginScreen(Screen):
    def login(self):
        email = self.ids.email.text
        password = self.ids.password.text
        cursor.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
        if cursor.fetchone():
            self.manager.current = 'dashboard'
        else:
            self.ids.error.text = 'Invalid login!'

class RegisterScreen(Screen):
    def register(self):
        email = self.ids.email.text
        password = self.ids.password.text
        cursor.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
        conn.commit()
        self.manager.current = 'login'

class DashboardScreen(Screen):
    pass

# Screen manager
class MoraPOSApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(DashboardScreen(name='dashboard'))
        return sm

MoraPOSApp().run()
